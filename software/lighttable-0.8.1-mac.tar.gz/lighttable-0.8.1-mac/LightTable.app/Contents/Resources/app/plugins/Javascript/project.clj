(defproject com.lighttable/javascript "0.2.0"
  :description "Javascript plugin for Light Table"
  :dependencies [[org.clojure/clojure "1.5.1"]])
