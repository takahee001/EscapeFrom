## HTML for Light Table

The official HTML language plugin for Light Table.

## Commands

This plugin comes with a command to jump between matching tags. By default this command is bound to 'alt-j'.

###License

Copyright (C) 2013 Kodowa Inc.

Distributed under the MIT license, see license.md for the full text.
