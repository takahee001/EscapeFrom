(defproject com.lighttable/python "0.0.7"
  :description "Python language plugin for Light Table"
  :dependencies [[org.clojure/clojure "1.5.1"]])
