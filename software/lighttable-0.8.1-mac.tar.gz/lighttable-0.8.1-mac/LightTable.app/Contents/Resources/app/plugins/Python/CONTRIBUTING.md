See [Light Table's CONTRIBUTING.md](https://github.com/LightTable/LightTable/blob/master/CONTRIBUTING.md).
